# 快速体验夜莺v3
1. cd dockerfiles
2.  docker-compose up
3. 修改hosts 加入 127.0.0.1 n9e.example.com
4. 浏览器访问 http://n9e.example.com
5. 用户名 root  密码 root.2020