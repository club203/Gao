package config

const Version = 1
