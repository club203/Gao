package acache

func Init() {
	MaskCache = NewMaskCache()
	StraCache = NewStraCache()
}
