package config

const (
	SMS_QUEUE_NAME   = "/queue/rdb/sms"
	MAIL_QUEUE_NAME  = "/queue/rdb/mail"
	VOICE_QUEUE_NAME = "/queue/rdb/voice"
	IM_QUEUE_NAME    = "/queue/rdb/im"
)
