package http

import (
	"nightingale-club203/src/modules/rdb/config"
	"github.com/gin-gonic/gin"
)

func ldapUsed(c *gin.Context) {
	renderData(c, config.Config.LDAP.DefaultUse, nil)
}
