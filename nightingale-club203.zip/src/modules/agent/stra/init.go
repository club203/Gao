package stra

import "nightingale-club203/src/models"

var Collect models.Collect

func Init() {
	GetCollects()
}
