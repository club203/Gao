#!/bin/bash

curl -X POST  \
	http://localhost:8008/api/transfer/which-tsdb -d '{}'

