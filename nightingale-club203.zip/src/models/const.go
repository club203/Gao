package models

const InnerTenantIdent = "inner"
